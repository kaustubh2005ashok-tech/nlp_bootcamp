import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from datetime import datetime, timedelta


# ============================================================================
# DATASET 3: BUILDING LOAD DATA (Hourly Electricity Consumption)
# ============================================================================

def generate_building_load_data(n_days=365):
    """
    Generate hourly electricity load for a commercial building
    """
    np.random.seed(42)
    
    times = pd.date_range(start='2023-01-01', periods=n_days*24, freq='H')
    
    data = []
    for time in times:
        hour = time.hour
        day_of_week = time.weekday()
        month = time.month
        
        # Base load (always-on equipment)
        base_load = 50  # kW
        
        # HVAC load (temperature dependent)
        temp_celsius = 20 + 10 * np.sin(2 * np.pi * (time.dayofyear - 80) / 365)
        temp_celsius += 5 * np.sin(2 * np.pi * (hour - 6) / 24)
        
        # Cooling load (summer)
        if temp_celsius > 24:
            hvac_load = 100 + 10 * (temp_celsius - 24)
        # Heating load (winter)
        elif temp_celsius < 18:
            hvac_load = 80 + 8 * (18 - temp_celsius)
        else:
            hvac_load = 30
        
        # Occupancy pattern
        is_workday = day_of_week < 5  # Monday-Friday
        if is_workday:
            if 8 <= hour <= 18:  # Business hours
                occupancy_factor = 1.0
            elif 6 <= hour < 8 or 18 < hour <= 20:  # Ramp up/down
                occupancy_factor = 0.5
            else:
                occupancy_factor = 0.1
        else:  # Weekend
            occupancy_factor = 0.2
        
        # Lighting and plug loads
        occupancy_load = 150 * occupancy_factor
        
        # Total load
        total_load = base_load + hvac_load + occupancy_load
        total_load += np.random.normal(0, 10)  # Add noise
        
        data.append({
            'timestamp': time,
            'hour': hour,
            'day_of_week': day_of_week,
            'month': month,
            'is_workday': is_workday,
            'outdoor_temp': round(temp_celsius, 1),
            'load_kw': round(total_load, 2)
        })
    
    return pd.DataFrame(data)

# ============================================================================
# EXAMPLE 3: BUILDING LOAD CLUSTERING
# ============================================================================

def building_load_clustering():
    """
    Cluster daily load patterns using K-Means
    """
    from sklearn.cluster import KMeans
    from sklearn.preprocessing import StandardScaler
    
    print("\n" + "=" * 70)
    print("EXAMPLE 3: BUILDING LOAD PATTERN CLUSTERING")
    print("=" * 70)
    
    # Generate data
    print("\n1. Generating building load data...")
    df = generate_building_load_data(n_days=365)
    
    # Create daily load curves (24 hourly values per day)
    print("\n2. Creating daily load profiles...")
    df['date'] = df['timestamp'].dt.date
    
    # Pivot to get 24 columns (one per hour)
    daily_profiles = df.pivot(index='date', columns='hour', values='load_kw')
    
    print(f"   Shape: {daily_profiles.shape} (days x hours)")
    
    # Normalize each day by its mean (focus on shape, not magnitude)
    daily_profiles_norm = daily_profiles.div(daily_profiles.mean(axis=1), axis=0)
    
    # Clustering
    print("\n3. Performing K-Means clustering...")
    n_clusters = 4
    scaler = StandardScaler()
    profiles_scaled = scaler.fit_transform(daily_profiles_norm)
    
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(profiles_scaled)
    
    # Add cluster labels back to dataframe
    daily_profiles['cluster'] = clusters
    
    # Analyze clusters
    print(f"\n4. Cluster Analysis (n_clusters={n_clusters}):")
    for i in range(n_clusters):
        cluster_days = daily_profiles[daily_profiles['cluster'] == i]
        print(f"\n   Cluster {i}: {len(cluster_days)} days")
        
        # Get typical dates in this cluster
        sample_dates = cluster_days.head(3).index.tolist()
        print(f"   Sample dates: {', '.join([str(d) for d in sample_dates])}")
        
        # Characteristics
        avg_profile = cluster_days.iloc[:, :24].mean()
        peak_hour = avg_profile.idxmax()
        peak_load = avg_profile.max()
        print(f"   Peak hour: {peak_hour}:00, Average peak load: {peak_load:.1f} kW")
    
    return df, daily_profiles, kmeans

# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    print("\n")
    print("*" * 70)
    print("Introduction to AI and Data Science for Energy")
    print("*" * 70)
    
    # Run Example 3
    load_df, daily_profiles, kmeans = building_load_clustering()
    
    # Save dataset
    load_df.to_csv('building_load_data.csv', index=False)
    print("\n   ✓ Dataset saved: building_load_data.csv")
    
    print("\n" + "=" * 70)
    print("=" * 70)
    print("\nGenerated Datasets:")
    print("  3. building_load_data.csv - 365 days of hourly building loads")
    print("=" * 70)